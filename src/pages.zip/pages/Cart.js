import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'

const Cart = () => {
  return (
    <div>
      <Header />
      <h1 style={{marginTop:60}}>Cart Details</h1>
      <Footer />
    </div>
  )
}

export default Cart
