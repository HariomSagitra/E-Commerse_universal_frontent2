import React from 'react'
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Index from '../pages/Index'
import Login from '../pages/Login'
import Register from '../pages/Register'
import ProductDetails from '../pages/ProductDetails'
import Customer from '../pages/Customer'
import Admin from '../pages/Admin'
import Logout from '../pages/Logout'
import CustomerProductDetails from '../pages/CustomerProductDetails'
import Cart from '../pages/Cart'
const RouterDemo = () => {
  return (
    <div>
        <Router>
            <Routes>
                <Route path='/' element={<Index />}></Route>
                <Route path='/login' element={<Login />}></Route>
                <Route path='/logout' element={<Logout />}></Route>
                <Route path='/register' element={<Register />}></Route>
                <Route path='/customer' element={<Customer />}></Route>
                <Route path='/admin' element={<Admin />}></Route>
                <Route path='/productdetails/:pid' element={<ProductDetails />}></Route>
                <Route path='/customer/productdetails/:pid' element={<CustomerProductDetails />}></Route>
                <Route path='/customer/cart' element={<Cart />}></Route>
            </Routes>
        </Router>
    </div>
  )
}

export default RouterDemo
