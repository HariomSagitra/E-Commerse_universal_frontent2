import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'

const Admin = () => {
  return (
    <div>
        <Header />
        <h1 style={{margin:60}}>Admin Page</h1>
        <Footer />
    </div>
  )
}

export default Admin
