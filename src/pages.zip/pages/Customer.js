import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { PRODUCT_LIST,C_URL } from '../utility/Constant'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { Link } from 'react-router-dom'

const Customer = () => {
  const [pList, setpList] = useState([])
  
    const getAllProduct = () => {
        axios.get(PRODUCT_LIST)
            .then((response) => {
                console.log(response)
                setpList(response.data.allproduct)
            })
            .catch((err) => {
                console.log(err)
            })
    }
  
    useEffect(() => {
        getAllProduct()
    }, [])
    
  return (
    <div>
        <Header />
        <section className="bg0 p-t-75 p-b-140">
                        <div className="container">
                            <div className="row isotope-grid">
                                {pList.map((p, index) =>
                                    <div className="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item"
                                        key={index}
                                    >
                                        <div className="block2">
                                            <div className="block2-pic hov-img0">
                <img src={p.product_imageurl[2].path} alt="IMG-PRODUCT" height={320} />
                <Link 
                to={`${C_URL}customer/productdetails/${p._id}`}
                className="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1"	
                >
                                                    Quick View
                                                </Link>
                                                
                                            </div>
        
                                            <div className="block2-txt flex-w flex-t p-t-14">
                                                <div className="block2-txt-child1 flex-col-l ">
                                                    <a href="product-detail.html" className="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">
                                                        {p.product_description}
                                                    </a>
        
                                                    <span className="stext-105 cl3">
                                                        &#8377;{p.product_mrp}
                                                    </span>
                                                </div>
        
                                                <div className="block2-txt-child2 flex-r p-t-3">
                                                    <a href="#" className="btn-addwish-b2 dis-block pos-relative js-addwish-b2">
                                                        <img className="icon-heart1 dis-block trans-04" src="images/icons/icon-heart-01.png" alt="ICON" />
                                                        <img className="icon-heart2 dis-block trans-04 ab-t-l" src="images/icons/icon-heart-02.png" alt="ICON" />
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}
        
                            </div>
                        </div>
        </section>
        <Footer />
    </div>
  )
}

export default Customer
